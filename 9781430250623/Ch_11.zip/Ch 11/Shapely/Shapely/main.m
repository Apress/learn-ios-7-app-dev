//
//  main.m
//  Shapely
//
//  Created by James Bucanek on 10/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SYAppDelegate class]));
    }
}
