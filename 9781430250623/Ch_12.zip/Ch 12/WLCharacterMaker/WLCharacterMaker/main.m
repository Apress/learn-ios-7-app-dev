//
//  main.m
//  WLCharacterMaker
//
//  Created by James Bucanek on 5/11/13.
//  Copyright (c) 2013 Dawn to Dusk Software. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kImageKey		@"image"
#define kNameKey		@"name"
#define kDescriptionKey	@"description"

int main(int argc, const char * argv[])
{

	@autoreleasepool {
	    
	    // Create the dictionary for the Wonderland app and save it as a property list
		NSArray *dataModel = @[
			@{ kNameKey:@"Alice",			kImageKey:@"char-alice",	kDescriptionKey:@"Alice is seven and a half years old, quaintly logical, and resolutely independant. She's fond of sweets and books with pictures."},
			@{ kNameKey:@"White Rabbit",	kImageKey:@"char-rabbit",	kDescriptionKey:@"Perpetually late, the White Rabbit is the first character Alice sees. He's a nervous little fellow that does not like his house invaded by little girls, regardless of size."},
			@{ kNameKey:@"The Dodo",		kImageKey:@"char-dodo",		kDescriptionKey:@"An officious bird, the Dodo presides over the Caucus race, in which everyone wins, even Alice."},
			@{ kNameKey:@"The Caterpillar",	kImageKey:@"char-caterpillar",kDescriptionKey:@"The Caterpillar is a hookah-smoking caterpilla exactly three inches high which, according to him, \"is a very good height indeed\" (though Alice believes it to be a wretched height)."},
			@{ kNameKey:@"The Flamingo",	kImageKey:@"char-flamingo",	kDescriptionKey:@"The chief difficulty Alice found at first was in managing her flamingo."},
			@{ kNameKey:@"The Hatter",		kImageKey:@"char-madhatter",kDescriptionKey:@"Quite mad, the hatter and the March Hare were sentenced to perpetual tea time. He is fond of riddles and poetry."}
			   ];
	    [dataModel writeToFile:[@"~/Desktop/Characters.nsarray" stringByExpandingTildeInPath] atomically:NO];
	}
    return 0;
}

