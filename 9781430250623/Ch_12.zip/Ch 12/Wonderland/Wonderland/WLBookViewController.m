//
//  WLBookViewController.m
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "WLBookViewController.h"

#import "WLBookDataSource.h"


@interface WLBookViewController ()
{
	WLBookDataSource *bookSource;	// holds strong reference to dataSource
}
@end


@implementation WLBookViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	// Create the data source for the book and connect it to the controller.
	// This can't be done in Intrface Builder because of ARC: the dataSource
	//	is an "assign" outlet, and does not retain the object. Creating the
	//	data source object in the storyboard file and attaching it to the
	//	dataSource is insufficient to keep the object alive. It is immediately
	//	distroyed, and the page controller has no database.
	// The solution is to define a second, strong, reference (bookSource) that
	//	keeps the data source object from being destroyed.
	self.dataSource = bookSource = [WLBookDataSource new];
	
	// Load the text of the book into the data source's paginator.
	// The text is stored in the 'Alice.txt' resource file.
	NSURL *bookURL = [[NSBundle mainBundle] URLForResource:@"Alice"
											 withExtension:@"txt"];
	NSString *text = [NSString stringWithContentsOfURL:bookURL
											  encoding:NSUTF8StringEncoding
												 error:NULL];
	bookSource.paginator.bookText = text;
	
	// A page controller must be manually initialized with the initial set of
	//	sub-controllers (read pages). This can't be configured in Interface Builder.
	[self setViewControllers:@[[bookSource pageViewController:self loadPage:1]]
				   direction:UIPageViewControllerNavigationDirectionForward
					animated:NO
				  completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
