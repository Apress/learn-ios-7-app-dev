//
//  WLOnePageViewController.m
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "WLOnePageViewController.h"

@interface WLOnePageViewController ()
- (void)loadPageContent;
@end

@implementation WLOnePageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews
{
	// Receieved whenever the subviews are layed out. This, most likely,
	//	means that the text view's size has changed. The paginator needs
	//	to recalculate the amount of text that will fit in the view.
	[super viewDidLayoutSubviews];
	[self loadPageContent];
}

- (void)loadPageContent
{
	// Prepare the paginator so it performs its calculations based on the current
	//	view size. Under normal circumstances, this will cause the paginator to
    //  reset once. After that, the size remains the same and the cached page
    //  calculations are used until something change that, like an orientation change.
	_paginator.viewSize = _textView.bounds.size;
    
	// Handle the case where the new layout/orientation has caused this page
	//	to no longer exist (because it's now beyond the end of the 'book').
	if (![_paginator availablePage:_pageNumber])
		_pageNumber = _paginator.lastKnownPage;
    
	// Fill the view with the text for this page using the paginator's font attributes
    _textView.fontAttrs = _paginator.fontAttrs;
	_textView.text = [_paginator textForPage:_pageNumber];
    [_textView setNeedsDisplay];
	// Display the page number at the bottom
	_pageLabel.text = [NSString stringWithFormat:@"Page %u",(unsigned int)_pageNumber];
    
}

@end
