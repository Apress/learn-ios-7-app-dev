//
//  CMColor.m
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "CMColor.h"

@implementation CMColor

+ (NSSet*)keyPathsForValuesAffectingColor
{
	return [NSSet setWithObjects:@"hue",@"saturation",@"brightness",nil];
}

- (UIColor*)color
{
	return [UIColor colorWithHue:self.hue/360
					  saturation:self.saturation/100
					  brightness:self.brightness/100
						   alpha:1];
}

- (NSString*)rgbCodeWithPrefix:(NSString*)prefix
{
	if (prefix==nil)
		prefix = @"";
    
	CGFloat red, green, blue, alpha;
	[self.color getRed:&red green:&green blue:&blue alpha:&alpha];
	return [NSString stringWithFormat:@"%@%02lx%02lx%02lx",
			prefix,
			lroundf(red*255),
			lroundf(green*255),
			lroundf(blue*255)];
}

@end
