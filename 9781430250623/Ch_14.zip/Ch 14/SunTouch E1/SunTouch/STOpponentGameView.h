//
//  STOpponentGameView.h
//  SunTouch
//
//  Created by James Bucanek on 2/3/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "STGameView.h"

@interface STOpponentGameView : STGameView

@end
