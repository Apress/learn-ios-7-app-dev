//
//  STStrike.m
//  SunTouch
//
//  Created by James Bucanek on 1/23/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "STStrike.h"

@implementation STStrike

@synthesize location;
@synthesize radius;

@end
