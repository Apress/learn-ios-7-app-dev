//
//  STMainViewController.m
//  SunTouch
//
//  Created by James Bucanek on 10/31/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "STMainViewController.h"

#import "STGameViewController.h"


@interface STMainViewController ()
- (void)gameEndedNotification:(NSNotification*)notification;
@end


@implementation STMainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Flipside View Controller

- (void)flipsideViewControllerDidFinish:(STFlipsideViewController *)controller
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.flipsidePopoverController dismissPopoverAnimated:YES];
    }
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    self.flipsidePopoverController = nil;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showAlternate"]) {
        [[segue destinationViewController] setDelegate:self];
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            UIPopoverController *popoverController = [(UIStoryboardPopoverSegue *)segue popoverController];
            self.flipsidePopoverController = popoverController;
            popoverController.delegate = self;
        }
    }
	else if ([segue.destinationViewController isKindOfClass:[STGameViewController class]])
		{
		// Register to receive "game over" notifications.
		// It's the main controller's responsibility to close the modal
		//	game view controller when the game is over.
		[[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(gameEndedNotification:)
													 name:kGameDidEndNotifcation
												   object:nil];
		}
}

- (IBAction)togglePopover:(id)sender
{
    if (self.flipsidePopoverController) {
        [self.flipsidePopoverController dismissPopoverAnimated:YES];
        self.flipsidePopoverController = nil;
    } else {
        [self performSegueWithIdentifier:@"showAlternate" sender:sender];
    }
}

#pragma mark Game View Controller

- (void)gameEndedNotification:(NSNotification *)notification
{
	// The kGameDidEndNotifcation is when the game is over and
	//	it wants the game view controller to return to the main view.
	
	// Receiving a kGameDidEndNotifcation implies that this view controller has presented
	//	the model STGameViewController, and now it wants it to close.
	[self dismissViewControllerAnimated:YES completion:NULL];
}

@end
