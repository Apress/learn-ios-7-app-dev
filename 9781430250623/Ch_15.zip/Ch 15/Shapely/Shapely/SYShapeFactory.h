//
//  SYShapeFactory.h
//  Shapely
//
//  Created by James Bucanek on 11/8/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SYShapeView.h"
#import "SYViewController.h"


@interface SYShapeFactory : NSObject

@property (strong,nonatomic) IBOutlet SYShapeView               *shapeView;
@property (strong,nonatomic) IBOutlet UITapGestureRecognizer    *dblTapGesture;
@property (strong,nonatomic) IBOutlet UITapGestureRecognizer    *trplTapGesture;

- (SYShapeView*)loadShape:(ShapeSelector)shape forViewController:(SYViewController*)controller;

@end
