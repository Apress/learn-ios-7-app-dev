//
//  SYShapeFactory.m
//  Shapely
//
//  Created by James Bucanek on 11/8/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "SYShapeFactory.h"

@interface SYShapeFactory () // private
+ (NSString*)nibNameForShape:(ShapeSelector)shape;
@end

@implementation SYShapeFactory

+ (NSString*)nibNameForShape:(ShapeSelector)shape
{
    switch (shape) {
        case kRectangleShape:
        case kOvalShape:
            return @"RectangleShape";
            
        default:
            return @"SquareShape";
    }
}

- (SYShapeView*)loadShape:(ShapeSelector)shape forViewController:(SYViewController*)controller;
{
    // The nib file containing the shape and gesture recognizers requires two placeholder objects:
    //  owner: self
    //  viewController: the SYViewController that will be the target of actions
    // The file's owner placeholder is passed in the owner: parameter. All additional
    //  placeholder objects are passed via the options: parameter.
    
    // Construct the dictionary of additional placeholder objects (there's only one)
    NSDictionary *placeholders = @{ @"viewController": controller };
    // Construct the options dictionary
    NSDictionary *options = @{ UINibExternalObjects: placeholders };
    
    // Load the correctly shaped nib file, specifying this object as the file's owner
    // The -loadNibNamed:owner:options: message returns an array of the top-level objects
    //  that was in the nib file, but this code doesn't need them because all of the
    //  objects it's interested in are connected to the outlets.
    [[NSBundle mainBundle] loadNibNamed:[SYShapeFactory nibNameForShape:shape]
                                  owner:self
                                options:options];
    
    // Set the shape property
    self.shapeView.shape = shape;
    
    // Establish the gesture recognizer dependency; this must be done programmatically.
	// Create a dependency between the double- and triple- tap gesture recognizers,
	//	else the double-tap will always be recognized before the triple-tap can.
	[_dblTapGesture requireGestureRecognizerToFail:_trplTapGesture];
    
    return _shapeView;
}

@end
