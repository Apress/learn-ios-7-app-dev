//
//  SYShapeView.m
//  Shapely
//
//  Created by James Bucanek on 10/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "SYShapeView.h"


#define kStrokeWidth			8.0f

@interface SYShapeView ()
@property (readonly,nonatomic) UIBezierPath *path;
@end


@implementation SYShapeView

#pragma mark Properties

- (void)setColor:(UIColor *)color
{
    _color = color;
    [self setNeedsDisplay];
}

- (UIBezierPath*)path
{
	// Calculate the rect that will contain the points of the Bezier curve.
	// In Core Graphics, the "ink" of the line draws on either side of the
	//	logical line of the curve. So the actual pixels drawn will extend
	//	1/2 the width of the lineWidth on either side. Inset the rect one
	//	additional pixel so the graphic engine will have one pixel outside
	//	the line and end points to perform anti-aliasing.
	CGRect bounds = self.bounds;
	CGRect rect = CGRectInset(bounds,kStrokeWidth/2+1,kStrokeWidth/2+1);
	
	// Based on the shape selector, create the bezier path that will draw that
	//	shape inside |rect| and store it in |path|.
	UIBezierPath *path;
	switch (_shape) {
		case kSquareShape:
		case kRectangleShape:
			// The only difference between a square and a rectangle is the
			//	aspect ratio of the view, which is set by bounds.
			path = [UIBezierPath bezierPathWithRect:rect];
			break;
			
		case kCircleShape:
		case kOvalShape:
			// The only difference between a circle and an oval is the
			//	aspect ratio of the view, which is set by bounds.
			path = [UIBezierPath bezierPathWithOvalInRect:rect];
			break;
			
		case kTriangleShape:
			// Create a bezier path from the center top of the view, to
			//	the lower right corner, and then the lower left corner.
			// Note: This is not an equilateral triangle. If you wanted
			//		 that, you'd have to shorten the height so it was
			//		 sqrt(3)/2 the length of the base, and then you'd
			//		 probably want to vertically center the points.
			path = [UIBezierPath bezierPath];
			CGPoint point = CGPointMake(CGRectGetMidX(rect),CGRectGetMinY(rect));
			[path moveToPoint:point];
			point = CGPointMake(CGRectGetMaxX(rect),CGRectGetMaxY(rect));
			[path addLineToPoint:point];
			point = CGPointMake(CGRectGetMinX(rect),CGRectGetMaxY(rect));
			[path addLineToPoint:point];
			// Close the line from the bottom corner back to the top.
			[path closePath];
			break;
			
		case kStarShape:
			// Create a star shaped path. Begin at the "top" with a point
			//	centered at the top of the view. Using a loop, calculate
			//	the next ten points of the star.
			// Note: Remember that the origin (0,0) of the Core Graphics coordinate
			//		 system is in the upper left corner. This means the Y
			//		 axis is inverted from the Cartesian coordinates used
			//		 by trigonometric functions. So angles that increase (+)
			//		 are moving clockwise in Core Graphics coordinates
			//		 (rather than counter-clockwise, in Cartesian coordinates).
			path = [UIBezierPath bezierPath];
			point = CGPointMake(CGRectGetMidX(rect),CGRectGetMinY(rect));
			float angle = M_PI*2/5;	// initial angle is 72° (clockwise from horizontal)
			float distance = rect.size.width*0.38f;
			// Note: This "magic number" (0.38) is the approximate ratio of the
			//		 length of a single line segment in a golden star to its width.
			//		 Go ahead, do the math.
			[path moveToPoint:point];
			for ( NSUInteger arm=0; arm<5; arm++ )
				{
				// Calculate the next inner point from the coordinates
				//	of the last outer point (peak) of the star.
				//	|angle| contains the direction from the last point
				//	to the next inner point. Move the point along
				//	that angle for the given distance.
				point.x += cosf(angle)*distance;
				point.y += sinf(angle)*distance;
				// Add the line segment to this inner point to the path.
				[path addLineToPoint:point];
				// Rotate the direction of travel -72°. The direction is
				//	now pointed towards the next outer point.
				angle -= M_PI*2/5;
				// Move to the next outer point and add a line segment.
				point.x += cosf(angle)*distance;
				point.y += sinf(angle)*distance;
				[path addLineToPoint:point];
				// Rotate the angle of travel +144°. The angle is now
				//	pointed towards the next inner point.
				angle += M_PI*4/5;
				// Loop around, adding the next two points.
				}
			// Close the path, connecting the last point to the first point.
			// For line shapes like the star, this is only important because it
			//	turns the first and last points into a  "joint" instead of two
			//	line "caps". This affects how the stroke is drawn around that point.
			[path closePath];
			break;
    }
	// Set the common path properties
	path.lineWidth = kStrokeWidth;
	path.lineJoinStyle = kCGLineJoinRound;
    
	// Return the finished path to the sender
	return path;
}

#pragma mark Drawing

- (void)drawRect:(CGRect)rect
{
	UIBezierPath *path = self.path;
    
	// Fill the shape with black at 30% opacity. This creates the illusion of a
	//	thin "screen" which slighly darkens other views that are behind this one.
	[[[UIColor blackColor] colorWithAlphaComponent:0.3] setFill];
	[path fill];
    
	// Draw the outline of the shape using this shape's color.
	// Line width and other properties are already set in |path|.
	[self.color setStroke];
	[path stroke];
}

@end
