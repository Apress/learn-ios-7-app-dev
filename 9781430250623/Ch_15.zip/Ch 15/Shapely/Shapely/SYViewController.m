//
//  SYViewController.m
//  Shapely
//
//  Created by James Bucanek on 10/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "SYViewController.h"

#import "SYShapeView.h"
#import "SYShapeFactory.h"

@interface SYViewController ()
{
	NSArray *colors;
}
@property (readonly,nonatomic) NSArray *colors;
- (IBAction)moveShape:(UIGestureRecognizer*)gesture;
- (IBAction)resizeShape:(UIPinchGestureRecognizer*)gesture;
- (void)corralShape:(SYShapeView*)shapeView;
- (IBAction)changeColor:(UITapGestureRecognizer*)gesture;
- (IBAction)sendShapeToBack:(UITapGestureRecognizer*)gesture;
@end

@implementation SYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Properties

- (NSArray*)colors
{
	// Lazily create an array of colors used for shapes.
	if (colors==nil)
		{
		colors = @[	UIColor.redColor,
                    UIColor.greenColor,
                    UIColor.blueColor,
                    UIColor.yellowColor,
                    UIColor.purpleColor,
                    UIColor.orangeColor,
                    UIColor.grayColor,
                    UIColor.whiteColor ];
		}
	return colors;
}

#pragma mark Actions

- (IBAction)addShape:(id)sender
{
	// Create a new shape, with a new color, and add it to the view
	SYShapeView *shapeView = [[SYShapeFactory new] loadShape:[sender tag]
                                           forViewController:self];
    
	// Assign the shape a random color
	shapeView.color = [self.colors objectAtIndex:arc4random_uniform(self.colors.count)];
	
	// Add the new shape to the view
	[self.view addSubview:shapeView];
	// Pick a random center point for the new shape that's at least one shape
	//	width from the edge of the view (meaning the shape won't be any closer
	//	than half its width from the edge).
	CGRect shapeFrame = shapeView.frame;
	CGRect safeRect = CGRectInset(self.view.bounds,
								  shapeFrame.size.width,shapeFrame.size.height);
	CGPoint newShapeLoc = CGPointMake(safeRect.origin.x+arc4random_uniform(safeRect.size.width),
									  safeRect.origin.y+arc4random_uniform(safeRect.size.height));
	shapeView.center = newShapeLoc;
	
	// Animate entrance of new shape
	shapeFrame = shapeView.frame;					// get the view's final frame
	CGRect buttonFrame = ((UIView*)sender).frame;	// get the frame of the button
                                                    // Start the new shape right over the button, and then animate it to its final location.
	shapeView.frame = buttonFrame;
	[UIView animateWithDuration:0.5
						  delay:0
						options:UIViewAnimationOptionCurveEaseOut
					 animations:^{
						 shapeView.frame = shapeFrame;
                         }
					 completion:nil];
}

- (IBAction)moveShape:(UIPanGestureRecognizer *)gesture
{
	SYShapeView *shapeView = (SYShapeView*)gesture.view;
	CGPoint dragDelta = [gesture translationInView:shapeView.superview];
	CGAffineTransform move;
	
	switch (gesture.state) {
		case UIGestureRecognizerStateBegan:
		case UIGestureRecognizerStateChanged:
			// The drag gesture has just began or is in progress:
			// Apply a transformation to make it look like the view
			//	is being dragged around underneath the user's finger.
			move = CGAffineTransformMakeTranslation(dragDelta.x,dragDelta.y);
			shapeView.transform = move;
			break;
			
		case UIGestureRecognizerStateEnded:
			// The drag gesture ended normally: move the shape to the final position
			shapeView.transform = CGAffineTransformIdentity;	// reset transform
                                                                // Move original frame by the distance of the drag
			shapeView.frame = CGRectOffset(shapeView.frame,dragDelta.x,dragDelta.y);
            [self corralShape:shapeView];
			break;
			
		default:
			// Any other state: the gesture was canceled or failed
            shapeView.transform = CGAffineTransformIdentity;
			break;
    }
}

- (IBAction)resizeShape:(UIPinchGestureRecognizer*)gesture
{
	SYShapeView *shapeView = (SYShapeView*)gesture.view;
	CGFloat pinchScale = gesture.scale;
	CGAffineTransform zoom;
	
	switch (gesture.state) {
		case UIGestureRecognizerStateBegan:
		case UIGestureRecognizerStateChanged:
			// The pinch gesture has just began or is in progress:
			// Apply a transformation to make it look like the view
			//	is being made bigger or smaller.
			zoom = CGAffineTransformMakeScale(pinchScale,pinchScale);
			shapeView.transform = zoom;
			break;
			
		case UIGestureRecognizerStateEnded:
			// The drag gesture ended normally: move the shape to the final position
			shapeView.transform = CGAffineTransformIdentity;	// reset transform
                                                                // Resize frame based on the final scale
			CGRect frame = shapeView.frame;
			CGFloat xDelta = frame.size.width*pinchScale-frame.size.width;
			CGFloat yDelta = frame.size.height*pinchScale-frame.size.height;
			frame.size.width += xDelta;
			frame.size.height += yDelta;
			frame.origin.x -= xDelta/2;
			frame.origin.y -= yDelta/2;
			shapeView.frame = frame;
			[shapeView setNeedsDisplay];
            [self corralShape:shapeView];
			break;
			
		default:
			// Any other state: the gesture was canceled or failed
            shapeView.transform = CGAffineTransformIdentity;
			break;
	}
}

- (void)corralShape:(SYShapeView*)shapeView
{
    // Keep the shape on the screen
    
    // Create a rect that defines the area shapes should be kept inside.
    // That method assumes that
    //  (a) the shape creation buttons are at the top of the view
    //  (b) the origin of the view is (0,0)
    //  (c) the root view contains shapeView
    //  (all pretty safe bets, but it doesn't hurt to document them)
    
    // Get the bounds of the superview and the current frame of the shape
    //  (which are both in the coordiante system of the superview)
    CGRect corralRect = self.view.bounds;
    CGRect shapeFrame = shapeView.frame;
    // Move the top edge down so it's below the bottom edge of the
    //  first button
    UIView *aNewShapeButton = [self.view viewWithTag:kSquareShape];
    CGFloat buttonBottom = CGRectGetMaxY(aNewShapeButton.frame);
    CGRect buttonArea; // (not used, just needed because |slice| param can't be NULL)
    CGRectDivide(corralRect,&buttonArea,&corralRect,buttonBottom,CGRectMinYEdge);
    
    // See if the shape view is already inside the allowed area
    if (!CGRectContainsRect(corralRect,shapeFrame))
        {
        // The shapeFrame is not completely contained in corralRect, which
        //  means that some portion of it has been moved outside the edge
        //  of the screen, or it's too big, or both.

        // Calculate a new frame for the view that keeps it on the screen
        
        // Step one: resize the shape so it fits in the allowed area
        if (shapeFrame.size.width>corralRect.size.width ||
            shapeFrame.size.height>corralRect.size.height)
            {
            // Either the heigth or width of the shape is bigger than allowed.
            // Calculate a resizing factor that will shrink it to fit.
            // This statement calculates scaling factors that, when multiplied
            //  with the shape's size, will scale it down so it's not larger
            //  then correlRect.
            // Hint: The MIN macro chooses the smaller of its two parameters.
            CGFloat scale = MIN(MIN(corralRect.size.width/shapeFrame.size.width,1.0f),
                                MIN(corralRect.size.width/shapeFrame.size.width,1.0f));
            // Based on the scaling factor, calculate the fraction of the view that
            //  will be trimmed off its height & width. Use this in the inset function.
            // (This makes the rect proportionally smaller without changing its center.)
            CGFloat trimFraction = (1.0f-scale)/2;
            shapeFrame = CGRectInset(shapeFrame,
                                     shapeFrame.size.width*trimFraction,
                                     shapeFrame.size.height*trimFraction);
            }
        
        // Step two: move the shape so it's inside the allowed area
        // Note: shapeRect can't, by definition, be larger than corralRect at
        //       this point, so the shape can be either above or below the area,
        //       but not both, and it could be to the left or right the area,
        //       but not both.
        CGFloat deltaX = 0;
        CGFloat deltaY = 0;
        if (CGRectGetMinX(shapeFrame)<CGRectGetMinX(corralRect))
            deltaX = CGRectGetMinX(corralRect)-CGRectGetMinX(shapeFrame);
        else if (CGRectGetMaxX(shapeFrame)>CGRectGetMaxX(corralRect))
            deltaX = CGRectGetMaxX(corralRect)-CGRectGetMaxX(shapeFrame);
        if (CGRectGetMinY(shapeFrame)<CGRectGetMinY(corralRect))
            deltaY = CGRectGetMinY(corralRect)-CGRectGetMinY(shapeFrame);
        else if (CGRectGetMaxY(shapeFrame)>CGRectGetMaxY(corralRect))
            deltaY = CGRectGetMaxY(corralRect)-CGRectGetMaxY(shapeFrame);
        shapeFrame = CGRectOffset(shapeFrame,deltaX,deltaY);
        
        // Last step: Animation the shape from where the user dropped it
        //  to where it ought to be.
        [UIView animateWithDuration:0.4 animations:^{ shapeView.frame = shapeFrame; } ];
        }
}

- (IBAction)changeColor:(UITapGestureRecognizer*)gesture
{
	// Get the shape's color
	SYShapeView *shapeView = (SYShapeView*)gesture.view;
	UIColor *color = shapeView.color;
	// Find the index of the color in the list of possible colors
	NSUInteger colorIndex = [self.colors indexOfObject:color];
	NSUInteger newIndex;
	// Pick a color at random, repeating if we picked the same color
	do {
		newIndex = arc4random_uniform(self.colors.count);
	} while (colorIndex==newIndex);
	// Assign the new color
	shapeView.color = [self.colors objectAtIndex:newIndex];
}

- (IBAction)sendShapeToBack:(UITapGestureRecognizer*)gesture
{
	SYShapeView *shapeView = (SYShapeView*)gesture.view;
	[self.view sendSubviewToBack:shapeView];
}

@end
