//
//  LRDialView.h
//  Leveler
//
//  Created by James Bucanek on 10/26/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LRDialView : UIView

@end
