//
//  LRDialView.m
//  Leveler
//
//  Created by James Bucanek on 10/26/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "LRDialView.h"

#define kInnerDialInset		(10.0f/100.0f)                          // 10% inset (diameter)
#define LRDialColor			[UIColor colorWithHue:208.0/360.0f		/* 208° hue */			\
                                       saturation:44.0f/100.0f		/* 44% saturation */	\
                                       brightness:90.0f/100.0f		/* 90% brightness */	\
                                            alpha:50.0f/100.0f]		/* 50% transparent */


#define kQuadrantTickInset		(8.0f/100.0f)	// 8% inset (radius)
#define kQuadrantFontSizeRatio	(72.0/670.0)    // 72pt @ 670px
#define kMajorTickInest			(5.0f/100.0f)	// 5%
#define kMajorFontSizeRatio		(48.0/670.0)    // 48pt @ 670px
#define kMinorTickInset			(2.5f/100.0f)	// 2.5%
#define kTickWidth				(4.0f)			// 2 pixel wide ticks
#define LRTickColor				[UIColor whiteColor]

#define kCircleDegrees			360
#define kQuadrantTickDegrees	90		// 0       90         180  ...
#define kMajorTickDegrees		30		//   30 60    120 150      ...
#define kMinorTickDegrees		3		// ||||||||||||||||||||||| ...


@implementation LRDialView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
		{
        self.clearsContextBeforeDrawing = YES;
		self.opaque = NO;
		}
    return self;
}

#pragma mark Drawing

- (void)drawRect:(CGRect)rect
{
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGRect bounds = self.bounds;
	CGFloat radius = bounds.size.height/2;
	
	//
	// Draw the "dial"
	//
	
	CGContextSaveGState(context);
	// Create a "doughnut" by filling a larger circle, and then filling
	//	an inset circle with transparent pixels.
	UIBezierPath *dial = [UIBezierPath bezierPathWithOvalInRect:self.bounds];
	[LRDialColor setFill];
	[dial fill];
	// Clear the inner circle
	CGRect innerBounds = CGRectInset(bounds,
									 radius*kInnerDialInset,
									 radius*kInnerDialInset);
	dial = [UIBezierPath bezierPathWithOvalInRect:innerBounds];
	[[UIColor clearColor] setFill];
	CGContextSetBlendMode(context,kCGBlendModeCopy);
	[dial fill];
	CGContextRestoreGState(context);
    
	//
	// Draw the ticks and labels around the dial
	//
	
	// Before the loop begins, offset all of the drawing by (radius,radius) so the
	//	logical origin (0,0) of the drawing context is now in the center of the view.
	CGContextTranslateCTM(context,radius,radius);
	// Note that the logical origin (0,0) of the context is now in the center
	//	of the view, so to draw a downward tick at the top center of the
	//	view, the coordinates are (0,-radius) to (0,-radius+tickHeight)
	CGPoint topCenter = CGPointMake(0,-radius);
    
	[LRTickColor set];							// color for both stroke and text
	CGContextSetLineWidth(context,kTickWidth);	// width of tick lines
                                                // Note: Use integer math for the angle loop to avoid rounding inaccuracies
                                                //		 inherent when using floating point numbers.
	for ( NSUInteger angle=0; angle<kCircleDegrees; angle+=kMinorTickDegrees )
		{
		// Determine the length of this tick, if it has a label, and the font size
		CGFloat tickLength;
		CGFloat labelSize;
		BOOL	label = NO;
		if (angle%kQuadrantTickDegrees==0)
			{
			// This is a quadrant tick
			tickLength = ceilf(bounds.size.height*kQuadrantTickInset);
			label = YES;
			labelSize = ceilf(bounds.size.height*kQuadrantFontSizeRatio);
			}
		else if (angle%kMajorTickDegrees==0)
			{
			// This is a major tick
			tickLength = ceilf(bounds.size.height*kMajorTickInest);
			label = YES;
			labelSize = ceilf(bounds.size.height*kMajorFontSizeRatio);
			}
		else
			{
			// This is a minor tick
			tickLength = ceilf(bounds.size.height*kMinorTickInset);
			}
		
		// Draw the tick using the CGContextStrokeLineSegments() function
		CGPoint points[2] = { topCenter, CGPointMake(topCenter.x,topCenter.y+tickLength) };
		CGContextStrokeLineSegments(context,points,2);
		
		if (label)
			{
			// Use the endpoint of the tick (in points[1]) to position the text
			//	centered immediately below it.
			NSString *labelText = [NSString stringWithFormat:@"%u",(unsigned int)angle];
            NSDictionary* labelAttrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:labelSize],
                                          NSForegroundColorAttributeName: LRTickColor };
			CGSize labelSize = [labelText sizeWithAttributes:labelAttrs];
			CGPoint textOrigin = points[1];				// top of label is at end point of tick
			textOrigin.x -= floorf(labelSize.width/2);	// center label by moving it left width/2
            [labelText drawAtPoint:textOrigin withAttributes:labelAttrs];
			}
        
		// Rotate the drawing coordinate system by one tick. The next line/label drawn will
		//	be rotated (around the origin, which is now in the center) by this angle. Each time
		//	through the loop, the transform is adjusted to the next angle, causing the ticks and
		//	labels to draw in a circle.
		CGContextConcatCTM(context,CGAffineTransformMakeRotation(kMinorTickDegrees*M_PI/180));
		}
}

@end
