//
//  LRViewController.m
//  Leveler
//
//  Created by James Bucanek on 10/26/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <CoreMotion/CoreMotion.h>

#import "LRViewController.h"

#import "LRDialView.h"

#define kHandImageName	@"hand"

#define kAccelerometerPollingInterval	(1.0/10.0)	/* 10 times a second */


@interface LRViewController ()
{
	CMMotionManager	*motionManager;
	LRDialView		*dialView;
	UIImageView		*needleView;
}
- (void)positionDialViews;
- (void)updateAccelerometerTime:(NSTimer*)timer;
- (void)rotateDialView:(double)rotation;
@end


@implementation LRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	// Programmatically create the dial and needle image views
	dialView = [[LRDialView alloc] initWithFrame:CGRectMake(0,0,100,100)];
	[self.view addSubview:dialView];
	needleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:kHandImageName]];
	needleView.contentMode = UIViewContentModeScaleAspectFit;
	[self.view insertSubview:needleView belowSubview:dialView];
	
	// Create the motion manager and configure it to report device motion/attitude
	//	changes 10 times per second.
	motionManager = [CMMotionManager new];
	motionManager.accelerometerUpdateInterval = kAccelerometerPollingInterval;
}

- (void)viewWillAppear:(BOOL)animated
{
	[self positionDialViews];
    
    // Tell the motion manager to begin collection accelerometer data
	[motionManager startAccelerometerUpdates];

    // Start a timer to periodically poll the accelerometer
	[NSTimer scheduledTimerWithTimeInterval:kAccelerometerPollingInterval
									 target:self
								   selector:@selector(updateAccelerometerTime:)
								   userInfo:nil
									repeats:YES];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[self positionDialViews];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Orientation

- (NSUInteger)supportedInterfaceOrientations
{
	// Allow iPhone interface to turn upside down
	return UIInterfaceOrientationMaskAll;
}

#pragma mark Layout

- (void)positionDialViews
{
	// Position the dial so its center is at the center of
	//	the bottom edge of the view, and its top edge is
    //  below the angle label.
	CGRect viewBounds = self.view.bounds;
    CGRect labelFrame = self.angleLabel.frame;
    CGFloat topEdge = CGRectGetMaxY(labelFrame)+labelFrame.size.height/3;
    // The dialView height/width is twice the size that appears in the view
    //  becuase half of it is always below screen.
	CGFloat dialHeight = ceilf((CGRectGetMaxY(viewBounds)-topEdge)*2);
    // (you can't change the frame while the transform is not
    //  the identity transform)
	dialView.transform = CGAffineTransformIdentity;
	dialView.frame = CGRectMake(0, 0, dialHeight, dialHeight);
	dialView.center = CGPointMake(CGRectGetMidX(viewBounds),CGRectGetMaxY(viewBounds));
	[dialView setNeedsDisplay];
	
	// Scale the needle so it's the same height as the dial and
	//	position it at the bottom, horizontally centered.
	CGSize needleSize = needleView.image.size;
	CGFloat needleScale = (dialHeight/2)/needleSize.height;
	CGRect needleFrame = CGRectMake(0,0,
									needleSize.width*needleScale,
									needleSize.height*needleScale);
	needleFrame.origin.x = CGRectGetMidX(viewBounds)-needleFrame.size.width/2;
	needleFrame.origin.y = CGRectGetMaxY(viewBounds)-needleFrame.size.height;
	needleView.frame = CGRectIntegral(needleFrame);
}

#pragma mark Periodic

- (void)updateAccelerometerTime:(NSTimer *)timer
{
	// The accelerometer hardware has new information.

	// Rotation is the angle *away* from gravity, so calculate the angle of the "up"
	//	vector (the opposite of the pull of gravity).
	CMAcceleration acceleration = motionManager.accelerometerData.acceleration;
	double rotation = atan2(-acceleration.x,-acceleration.y);
    
    // Rotate the dial to reflect the device's current attitude
    [self rotateDialView:rotation];
}

- (void)rotateDialView:(double)rotation
{
	// Rotate the dial by the angle of "up"
    dialView.transform = CGAffineTransformMakeRotation(rotation);

	// Update the label
	// Convert radians to degrees, then fix the range so it's always positive
	NSInteger degrees = round(-rotation*180.0/M_PI);
	if (degrees<0)
		degrees+=360;
	_angleLabel.text = [NSString stringWithFormat:@"%u\u00b0",(unsigned)degrees];
}

@end
