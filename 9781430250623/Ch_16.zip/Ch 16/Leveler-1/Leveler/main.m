//
//  main.m
//  Leveler
//
//  Created by James Bucanek on 10/26/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LRAppDelegate class]));
    }
}
