//
//  HPMapOptionsViewController.m
//  Pigeon
//
//  Created by James Bucanek on 10/29/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "HPMapOptionsViewController.h"

@interface HPMapOptionsViewController ()

@end

@implementation HPMapOptionsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
	// The segments of the control (0=Map, 1=Satellitem, 2=Hybrid)
	//	were choosen to correspond to the constants of the map view
	//	type (MKMapTypeStandard=0, MKMapTypeSatellite=1, and MKMapTypeHybrid=2).
	self.mapStyleControl.selectedSegmentIndex = self.mapView.mapType;
	// Similarly, the user tracking mode is either MKUserTrackingModeFollow (1)
	//	or MKUserTrackingModeFollowWithHeading (2), which gets converted
	//	to 0 or 1.
	self.headingControl.selectedSegmentIndex = self.mapView.userTrackingMode-1;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Actions

- (IBAction)changeMapStyle:(id)sender
{
	self.mapView.mapType = self.mapStyleControl.selectedSegmentIndex;
}

- (IBAction)changeHeading:(id)sender
{
	self.mapView.userTrackingMode = self.headingControl.selectedSegmentIndex+1;
}

- (IBAction)done
{
	[self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
