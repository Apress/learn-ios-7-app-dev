//
//  main.m
//  Pigeon
//
//  Created by James Bucanek on 10/29/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HPAppDelegate class]));
    }
}
