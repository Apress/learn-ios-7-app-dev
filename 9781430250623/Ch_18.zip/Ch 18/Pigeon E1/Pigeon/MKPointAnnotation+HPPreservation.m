//
//  MKPointAnnotation+HPPreservation.m
//  Pigeon
//
//  Created by James Bucanek on 11/8/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "MKPointAnnotation+HPPreservation.h"

#define kInfoLocationLatitude	@"lat"
#define kInfoLocationLongitude	@"long"
#define kInfoLocationTitle		@"title"

@implementation MKPointAnnotation (HPPreservation)

- (NSDictionary*)preserveState
{
	CLLocationCoordinate2D coord = self.coordinate;
	return @{
        kInfoLocationLatitude:	@(coord.latitude),
        kInfoLocationLongitude: @(coord.longitude),
        kInfoLocationTitle:     self.title
        };
}

- (void)restoreState:(NSDictionary*)state
{
	CLLocationCoordinate2D coord;
	coord.latitude = [state[kInfoLocationLatitude] doubleValue];
	coord.longitude = [state[kInfoLocationLongitude] doubleValue];
	self.coordinate = coord;
	self.title = state[kInfoLocationTitle];
}

@end
