//
//  HPViewController.h
//  Pigeon
//
//  Created by James Bucanek on 10/29/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#define kPreferenceMapType			@"HPMapType"
#define kPreferenceHeading			@"HPFollowHeading"
#define kPreferenceSavedLocation	@"HPLocation"

@interface HPViewController : UIViewController <MKMapViewDelegate>

@property (weak,nonatomic) IBOutlet MKMapView *mapView;

- (IBAction)dropPin:(id)sender;
- (IBAction)clearPin:(id)sender;

@end
