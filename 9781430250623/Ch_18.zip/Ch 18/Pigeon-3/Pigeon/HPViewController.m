//
//  HPViewController.m
//  Pigeon
//
//  Created by James Bucanek on 10/29/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "HPViewController.h"

#import "HPMapOptionsViewController.h"
#import "MKPointAnnotation+HPPreservation.h"

#define kArrowDisplayDistanceMin	50.0		// show the arrow at 50 meters


@interface HPViewController () <UIAlertViewDelegate>
{
	MKPointAnnotation	*savedAnnotation;
	UIImageView			*arrowView;
}
- (void)hideReturnArrow;
- (void)showReturnArrowAtPoint:(CGPoint)userPoint towards:(CGPoint)returnPoint;
- (void)setAnnotation:(MKPointAnnotation*)annotation;
- (void)preserveAnnotation;
- (void)restoreAnnotation;
@end

@implementation HPViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	
	// Restore the map type, tracking, and annotations from the user defaults
	_mapView.mapType = [userDefaults integerForKey:kPreferenceMapType];
    _mapView.userTrackingMode = [userDefaults integerForKey:kPreferenceHeading];

	[self restoreAnnotation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Seques

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if ([segue.identifier isEqualToString:@"mapOptions"])
		{
		[(HPMapOptionsViewController*)segue.destinationViewController setMapView:_mapView];
		}
}

#pragma mark Map

- (void)mapView:(MKMapView *)mapView didChangeUserTrackingMode:(MKUserTrackingMode)mode animated:(BOOL)animated
{
	// Force the traking mode to stay either "follow" or "follow with heading"
	// This is important because the subview assumes the user's location is always
	//	centered in the map.
	if (mode==MKUserTrackingModeNone)
		[mapView setUserTrackingMode:MKUserTrackingModeFollow];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
	// Delegate method that returns the annotation view object for a given annotation.
    
	// For the user's location annotation, return nil; the map will use the default blue dot.
	if (annotation==self.mapView.userLocation)
		return nil;
	
	// For the only other annotation object, use (or reuse) the standard MKPinAnnotationView object.
	NSString *pinID = @"Save";
	MKPinAnnotationView *view = (MKPinAnnotationView*)[_mapView dequeueReusableAnnotationViewWithIdentifier:pinID];
	if (view==nil)
		{
		view = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:pinID];
		view.canShowCallout = YES;
		view.animatesDrop = YES;
		//view.draggable = YES;     // If set, allows the user to move its location
		}
	return view;
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
	if (savedAnnotation!=nil)
		{
		// There's a savedAnnotation, which means there's something to point at
		
		// Calculate the distance, in meters, between the user's current location and
		//	the saved location. Thankfully, location services will do the math.
		CLLocationCoordinate2D coord = savedAnnotation.coordinate;
		CLLocation *toLoc = [[CLLocation alloc] initWithLatitude:coord.latitude
													   longitude:coord.longitude];
		CLLocationDistance distance = [userLocation.location distanceFromLocation:toLoc];
		if (distance>=kArrowDisplayDistanceMin)
			{
			// The user is far enough away from the saved loction to show the return arrow.
			// Convert the two map coordinates (user and saved) into graphics coordinates
			//	and use those to position and point the arrow.
			CGPoint userPoint = [mapView convertCoordinate:userLocation.coordinate
											 toPointToView:self.mapView];
			CGPoint savePoint = [mapView convertCoordinate:coord
											 toPointToView:self.mapView];
			[self showReturnArrowAtPoint:userPoint towards:savePoint];
			return;
			}
		}
	// Any condition that doesn't result in pointing the arrow should hide it
	[self hideReturnArrow];
}

- (void)hideReturnArrow
{
	arrowView.hidden = YES;
}

- (void)showReturnArrowAtPoint:(CGPoint)userPoint towards:(CGPoint)returnPoint
{
	if (arrowView==nil)
		{
		// Create an image view object with the arrow and layer it immediately on
		//	top of the map view.
		arrowView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"arrow"]];
		arrowView.opaque = NO;
		arrowView.alpha = 0.6;
		[self.mapView addSubview:arrowView];
		arrowView.hidden = YES;
		}
	
	// Define a code block that sets the location and rotation of the arrow
	// (UI coordinates are vertically flipped from Cartesian coorindates, so
    //  calculate the angle of (x,-y).)
	CGFloat angle = atan2f(returnPoint.x-userPoint.x,userPoint.y-returnPoint.y);
	CGAffineTransform rotation = CGAffineTransformMakeRotation(angle);
	void (^updateArrow)(void) = ^{
		arrowView.center = userPoint;
		arrowView.transform = rotation;
    };
	
	if (arrowView.hidden)
		{
		// The arrow view was previously hidden.
		// Make it appear immediately at the correct location and orientation
		updateArrow();
		arrowView.hidden = NO;
		}
	else
		{
		// Animate the arrow view to its new direction
		[UIView animateWithDuration:0.5 animations:updateArrow];
		}
}

#pragma mark Annotation

- (void)setAnnotation:(MKPointAnnotation*)annotation
{
	if ([savedAnnotation isEqual:annotation])
		return;
	if (savedAnnotation!=nil)
		[_mapView removeAnnotation:savedAnnotation];
	savedAnnotation = annotation;
	if (annotation!=nil)
		{
		[_mapView addAnnotation:annotation];
		[_mapView selectAnnotation:annotation animated:YES];
		}
}

#pragma mark Actions

- (IBAction)dropPin:(id)sender
{
	// Prompt the user for a callout title
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"What's here?"
													message:@"Type a label for this location."
												   delegate:self
										  cancelButtonTitle:@"Cancel"
										  otherButtonTitles:@"Remember", nil];
	alert.alertViewStyle = UIAlertViewStylePlainTextInput;
	alert.delegate = self;
	[alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	// The user chose a title for the location: get it and create the annotation
    
	// Get the location of the user (if known)
	CLLocation *location = _mapView.userLocation.location;
	if (location==nil)
		// There is no location available; do nothing
		return;
	
	// Get the name
	NSString *name = [[alertView textFieldAtIndex:0] text];
	name = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if (name.length==0)
        // User didn't type anything useful; substitute a default
		name = @"Over Here!";
	
	// Create a point annotation and add it to the map
	MKPointAnnotation *newAnnotation = [MKPointAnnotation new];
	newAnnotation.title = name;
	newAnnotation.coordinate = location.coordinate;
	[self setAnnotation:newAnnotation];
	
	[self preserveAnnotation];
}

- (IBAction)clearPin:(id)sender
{
	if (savedAnnotation!=nil)
		{
		[self setAnnotation:nil];
		[self preserveAnnotation];
		}
}

#pragma mark User Defaults

- (void)preserveAnnotation
{
	// Save the information about the current annotation
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	if (savedAnnotation!=nil)
		{
		NSDictionary *annotationInfo = [savedAnnotation preserveState];
		[userDefaults setObject:annotationInfo
						 forKey:kPreferenceSavedLocation];
		}
	else
		{
		[userDefaults removeObjectForKey:kPreferenceSavedLocation];
		}
}

- (void)restoreAnnotation
{
	// Get the information about the saved annotation from the user defaults
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	NSDictionary *restoreInfo = [userDefaults dictionaryForKey:kPreferenceSavedLocation];
	if (restoreInfo!=nil)
		{
		// There was a saved annotation.
		// Turn it into a real annotation object and either add it to the map,
		//	or replace the one that's there.
		MKPointAnnotation *restoreAnnotation = [MKPointAnnotation new];
		[restoreAnnotation restoreState:restoreInfo];
		[self setAnnotation:restoreAnnotation];
		}
}

@end
