//
//  WLBookDataSource.h
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "WLPaginator.h"
#import "WLOnePageViewController.h"


@interface WLBookDataSource : NSObject <UIPageViewControllerDataSource>

@property (readonly,nonatomic) WLPaginator *paginator;

- (WLOnePageViewController*)pageViewController:pageViewController loadPage:(NSUInteger)page;

@end
