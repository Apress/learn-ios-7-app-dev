//
//  WLBookDataSource.m
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "WLBookDataSource.h"


@interface WLBookDataSource () // private interface
{
	WLPaginator *paginator;		// instance variable for |paginator| property
}
@end


@implementation WLBookDataSource

- (WLPaginator*)paginator
{
	// Lazily create the paginator for this data source
	if (paginator==nil)
        {
		paginator = [WLPaginator new];
        paginator.font = [UIFont fontWithName:@"Times New Roman" size:18];
        }
	return paginator;
}

- (WLOnePageViewController*)pageViewController:(UIPageViewController*)pageViewController loadPage:(NSUInteger)page
{
	// Return the page controller for the specific page
	
	if (page<1 || ![paginator availablePage:page])
		// The page number is out of range: return nil (no controller/page)
		return nil;
	
	// Construct and initialize the view controller for a single page of the book.
	// The interface for the page is part of the storyboard, so ask the storyboard
	//	object to create the view controller and load its interface.
	WLOnePageViewController *controller;
	controller = [pageViewController.storyboard instantiateViewControllerWithIdentifier:@"OnePage"];
	
	// Connect the page controller to the working paginator, which has all of the
	//	page data for the book.
	controller.paginator = self.paginator;
	controller.pageNumber = page;
	return controller;
}

#pragma mark <UIPageViewControllerDataSource>

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
	   viewControllerAfterViewController:(UIViewController *)viewController
{
	// Return the next page controller, or nil if there's no next page
	NSUInteger currentPageNumber = ((WLOnePageViewController*)viewController).pageNumber;
	return [self pageViewController:pageViewController loadPage:currentPageNumber+1];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
	  viewControllerBeforeViewController:(UIViewController *)viewController
{
	// Return the previous page controller, or nil if this is the first page
	NSUInteger currentPageNumber = ((WLOnePageViewController*)viewController).pageNumber;
	return [self pageViewController:pageViewController loadPage:currentPageNumber-1];
}

@end
