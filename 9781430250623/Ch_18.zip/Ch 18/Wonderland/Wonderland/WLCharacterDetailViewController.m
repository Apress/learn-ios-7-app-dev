//
//  WLCharacterDetailViewController.m
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "WLCharacterDetailViewController.h"

#import "WLCharacterTableViewController.h"


@interface WLCharacterDetailViewController ()

@end


@implementation WLCharacterDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.nameLabel.text = _characterInfo[kNameKey];
	self.imageView.image = [UIImage imageNamed:_characterInfo[kImageKey]];
	self.descriptionView.text = _characterInfo[kDescriptionKey];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
