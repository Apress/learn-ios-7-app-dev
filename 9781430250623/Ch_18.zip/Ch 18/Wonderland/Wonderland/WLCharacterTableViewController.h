//
//  WLCharacterTableViewController.h
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kImageKey		@"image"
#define kNameKey		@"name"
#define kDescriptionKey	@"description"


@interface WLCharacterTableViewController : UITableViewController

@property (strong,nonatomic) NSArray *tableData;

@end
