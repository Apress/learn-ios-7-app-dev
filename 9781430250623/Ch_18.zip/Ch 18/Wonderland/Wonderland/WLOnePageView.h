//
//  WLOnePageView.h
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WLOnePageView : UIView

@property (strong,nonatomic) NSString *text;
@property (strong,nonatomic) NSDictionary *fontAttrs;

@end
