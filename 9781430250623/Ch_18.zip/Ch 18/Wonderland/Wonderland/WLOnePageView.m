//
//  WLOnePageView.m
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "WLOnePageView.h"

@implementation WLOnePageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
	[super drawRect:rect];		// super fills with backgroundColor
    [_text drawInRect:self.bounds withAttributes:_fontAttrs];
}

@end
