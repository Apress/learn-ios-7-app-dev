//
//  WLOnePageViewController.h
//  Wonderland
//
//  Created by James Bucanek on 10/15/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WLOnePageView.h"
#import "WLPaginator.h"


@interface WLOnePageViewController : UIViewController

@property (nonatomic) NSUInteger pageNumber;
@property (strong,nonatomic) WLPaginator *paginator;

@property (weak,nonatomic) IBOutlet WLOnePageView *textView;
@property (weak,nonatomic) IBOutlet UILabel *pageLabel;

@end
