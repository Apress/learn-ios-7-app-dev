//
//  MSDetailViewController.m
//  MyStuff
//
//  Created by James Bucanek on 9/24/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <MobileCoreServices/UTCoreTypes.h>

#import "MSDetailViewController.h"

@interface MSDetailViewController ()
{
	UIPopoverController *imagePopoverController;
}
@property (strong, nonatomic) UIPopoverController *masterPopoverController;
- (void)configureView;
- (void)presentImagePickerUsingCamera:(BOOL)useCamera;
- (void)dismissImagePicker;
@end

@implementation MSDetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }

    if (self.masterPopoverController != nil) {
        [self.masterPopoverController dismissPopoverAnimated:YES];
    }        
}

- (void)configureView
{
    // Update the user interface for the detail item.

	if (self.detailItem!=nil)
        {
	    self.nameField.text = self.detailItem.name;
		self.locationField.text = self.detailItem.location;
        self.imageView.image = self.detailItem.viewImage;
        }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Split view

- (void)splitViewController:(UISplitViewController *)splitController willHideViewController:(UIViewController *)viewController withBarButtonItem:(UIBarButtonItem *)barButtonItem forPopoverController:(UIPopoverController *)popoverController
{
    barButtonItem.title = NSLocalizedString(@"My Stuff", @"My Stuff");
    [self.navigationItem setLeftBarButtonItem:barButtonItem animated:YES];
    self.masterPopoverController = popoverController;
}

- (void)splitViewController:(UISplitViewController *)splitController willShowViewController:(UIViewController *)viewController invalidatingBarButtonItem:(UIBarButtonItem *)barButtonItem
{
    // Called when the view is shown again in the split view, invalidating the button and popover controller.
    [self.navigationItem setLeftBarButtonItem:nil animated:YES];
    self.masterPopoverController = nil;
}

#pragma mark Editing

- (IBAction)changedDetail:(id)sender
{
	if (sender==self.nameField)
		self.detailItem.name = self.nameField.text;
	else if (sender==self.locationField)
		self.detailItem.location = self.locationField.text;
	// Announce change to any object that's interested
	[self.detailItem postDidChangeNotification];
}

- (IBAction)choosePicture:(id)sender
{
	if (self.detailItem==nil)
		// There is no item to edit: ignore request to set its image
		return;
    
	// Determine the capabilities of the device
	BOOL hasPhotoLibrary = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary];
	BOOL hasCamera = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
	
    // If this device has neither a camera or a photo library, tell the user and do nothing.
	if (!hasPhotoLibrary && !hasCamera) // <-- comment out this line to test the failure logic
		{
        // Present a failure message explaining why the picture can't be changed
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"MyStuff cannot access a camera or photo library."
                                                       delegate:nil
                                              cancelButtonTitle:nil
                                              otherButtonTitles:@"I'm Sorry",nil];
        [alert show];
        return;
        }
	
    // We're going to present an interface, or at least ask: dismiss the keyboard first
    [self dismissKeyboard:self];
    
	if (hasPhotoLibrary && hasCamera)
        {
		// This device has BOTH a camera and a photo library:
		//	ask the user which they'd like to use
		UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil
																 delegate:self
														cancelButtonTitle:@"Cancel"
												   destructiveButtonTitle:nil
														otherButtonTitles:@"Take a Picture",@"Choose a Photo",nil];
		[actionSheet showInView:self.view];
		// The action sheet will appear and send a -actionSheet:clickedButtonAtIndex:
		//	when the user taps their choice.
		return;
        }
    
	// The device has either a camera or a photo library, but not both.
	// Start the image picker interface immediately with what they have.
	[self presentImagePickerUsingCamera:hasCamera];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch (buttonIndex) {
		case 0: // camera button
		case 1: // photo button
			[self presentImagePickerUsingCamera:(buttonIndex==0)];
			break;
    }
}

- (void)presentImagePickerUsingCamera:(BOOL)useCamera
{
	// Discard any stray imagePopoverController.
	// This is used later as a flag, so it must be nil if we don't use it.
	// (It's possible to enter -presentImagePickerUsingCamera: with
	//	imagePopoverController!=nil if a previous popover was dismissed by
	//	tapping outside of it or by another controller. The result would
	//	be a non-nil imagePopoverController that may, or may not, get used.'
	//	One solution would be to become the delegate for the popover
	//	controller and discard it if dismissed by the user, but this 1-liner
	//	avoids any possible confusion, so wins as the simpler solution.)
	imagePopoverController = nil;
	
	// Create the image picker controller
	UIImagePickerController *cameraUI = [UIImagePickerController new];
	// Set the source type to either the camera or the photo library
	cameraUI.sourceType = ( useCamera ? UIImagePickerControllerSourceTypeCamera
                                      : UIImagePickerControllerSourceTypePhotoLibrary );
	
	// Displays a controller that only allows still pictures
	cameraUI.mediaTypes = @[(NSString*)kUTTypeImage];
    
	// Make this object the image picker's delegate; this object will
	//	receive the "did pick image / take picture" or "canceled" message.
	cameraUI.delegate = self;
	
	if (useCamera || UIDevice.currentDevice.userInterfaceIdiom==UIUserInterfaceIdiomPhone)
        {
		// Presenting the camera interface OR this is an iPhone: user full screen controller
		[self presentViewController:cameraUI animated:YES completion:nil];
        }
	else
        {
		// Presenting the photo library picker on an iPad: must use a pop-over
		imagePopoverController = [[UIPopoverController alloc] initWithContentViewController:cameraUI];
		[imagePopoverController presentPopoverFromRect:self.imageView.frame
												inView:self.view
							  permittedArrowDirections:UIPopoverArrowDirectionAny
											  animated:YES];
        }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	NSString *mediaType = info[UIImagePickerControllerMediaType];
	
	// This app only captures still images
	if ([mediaType isEqualToString:(NSString*)kUTTypeImage])
        {
		// First try to get the edited image (cropped, rotated, whatever)
		UIImage *whatsitImage = info[UIImagePickerControllerEditedImage];
		if (whatsitImage==nil)
			// There was no edited image: use the original
			whatsitImage = info[UIImagePickerControllerOriginalImage];
		
		// If the user used the camera to take a new picture, they will
		//	expect that (original or cropped) image to be added
		//	to their camera roll.
		if (picker.sourceType==UIImagePickerControllerSourceTypeCamera)
			UIImageWriteToSavedPhotosAlbum(whatsitImage,nil,nil,nil);
		
		// Crop the image so it's square and scale it so it's never
		//	larger than 512x512. This is big enough to display a retina
		//	quality image in the iPad's 256x256 image view, but small
		//	enough that a hundred or so pictures will fit in memory.
        CGSize orgSize = whatsitImage.size;
        // Get the smaller (narrower) of the two dimensions
        CGFloat smallDimension = MIN(orgSize.height,orgSize.width);
        // Determine the crop size: use either 512 or the narrowest image
        //  dimension, whichever is smaller, and then round that down
        //  to an even integer.
        NSUInteger i = MIN(512,(NSUInteger)smallDimension);
        i -= (i%2);                 // Round down to an even integer
        CGFloat cropDimension = i;  // Convert back to float
        CGSize cropSize = CGSizeMake(cropDimension,cropDimension);
        
        // Create a graphics context the size of the cropped image
        UIGraphicsBeginImageContextWithOptions(cropSize,YES,1);
        // Calculate a rect with the same aspect ratio as the original
        //  image that is centered and fits exactly inside the context.
        CGFloat scale = cropDimension/smallDimension;
        CGRect drawRect = CGRectMake(cropDimension/2,
                                     cropDimension/2,
                                     orgSize.width*scale,
                                     orgSize.height*scale);
        drawRect.origin.x -= drawRect.size.width/2;
        drawRect.origin.y -= drawRect.size.height/2;
        // Draw the original image into the scaled rect.
        // This scales, rotates, and crops the image in one step
        [whatsitImage drawInRect:drawRect];
        // Replace the original image with the image in the context
        whatsitImage = UIGraphicsGetImageFromCurrentImageContext();
        // We're done with the off-screen graphics context
        UIGraphicsEndImageContext();
		
		// Update the image in both MyWhatsit and the detail view
		_detailItem.image = whatsitImage;
		self.imageView.image = whatsitImage;
		[_detailItem postDidChangeNotification];
        }
    
	// Dismiss the camera/photo picker interface and discard it
	[self dismissImagePicker];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	// Close the image picker interface and return to the detail view controller
	//	without making any changes to the selected image.
	[self dismissImagePicker];
}

- (void)dismissImagePicker
{
	// Dismiss the image picker interface and return to the detail view controller.
	if (imagePopoverController!=nil)
		{
		// Picker was presented using a popover controller: dismiss the popover
		[imagePopoverController dismissPopoverAnimated:YES];
		imagePopoverController = nil;
		}
	else
		{
		// Else, picker was presented in a full screen controller
		[self dismissViewControllerAnimated:YES completion:nil];
		}
}

- (IBAction)dismissKeyboard:(id)sender
{
	// Action message to stop editing the current text field, which
	//	dismisses the keyboard.
	[self.view endEditing:NO];
}

@end
