//
//  MSThingsDocument.m
//  MyStuff
//
//  Created by James Bucanek on 11/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "MSThingsDocument.h"

#import "MyWhatsit.h"

#define kThingsDocumentType		@"mystuff"
#define kThingsDocumentName		(@"Things I Own." kThingsDocumentType)

#define kThingsPreferredName	@"things.data"
#define kImagePreferredName		@"image.png"


@interface MSThingsDocument () // private
{
	NSFileWrapper	*docWrapper;
	NSMutableArray	*things;
}
- (void)whatsitDidChange:(NSNotification*)notification;
@end


@implementation MSThingsDocument

+ (NSURL*)documentURL
{
	// The "Things" document has a fixed name and is always stored in the ~/Documents,
	//	folder, located inside the app's local sandbox.
	static NSURL *docURL = nil;			// cached reference to finished URL
    
    if (docURL==nil)
		{
		NSFileManager *fileManager = [NSFileManager defaultManager];
		// The URL begins with the standard "~/Documents" directory
		docURL = [fileManager URLForDirectory:NSDocumentDirectory
									 inDomain:NSUserDomainMask
							appropriateForURL:nil
									   create:YES
										error:NULL];
		// Add to that, the package name of the document
		docURL = [docURL URLByAppendingPathComponent:kThingsDocumentName];
		}
    return docURL;
}

+ (MSThingsDocument*)documentAtURL:(NSURL *)url
{
	// Return a UIDocument for the existing package at |url|, or create a new one
	NSFileManager *fileManager = [NSFileManager defaultManager];
	MSThingsDocument *document = [[MSThingsDocument alloc] initWithFileURL:url];
	if ([fileManager fileExistsAtPath:url.path])
		{
		// Document package already exists: open it
		[document openWithCompletionHandler:^(BOOL success){
			if (success)
				{
				// The document has been opened successfully, which means
				//	there's a new data model. Notify the delegate.
				if ([document.delegate respondsToSelector:@selector(gotThings:)])
                    [document.delegate gotThings:document];
				}
            }];
		}
	else
		{
		// Document package does not exit: create it
		// Save the file, specifying that it should create the package
		[document saveToURL:url forSaveOperation:UIDocumentSaveForCreating
		  completionHandler:nil];
		}
	
	// Have the document observe change notifications from data model objects
	NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
	[notificationCenter addObserver:document
						   selector:@selector(whatsitDidChange:)
							   name:kWhatsitDidChangeNotification
							 object:nil];
	
	// Return the opened/created document
	return document;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark UIDocument

- (id)contentsForType:(NSString *)typeName error:(NSError *__autoreleasing *)outError
{
	// Sent by UIDocument when it wants to save a document.
	// Return the data to be saved.
	
	// The returned data can be as simple as an NSData object, but in this
	//	implementation you return an NSFileWrapper that describes multiple files
	//	to be saved in a package (folder). One of those files is an archived version
	//	of the things array. The rest of the files are PNG images.
	if (docWrapper==nil)
		{
		// Document has never been opened or saved
		// Create the (empty) directory wrapper the will contain all of the component file wrappers
		docWrapper = [[NSFileWrapper alloc] initDirectoryWithFileWrappers:nil];
		}
	
    // Lazily create the data model, if needed
	if (things==nil)
		things = [NSMutableArray array];

	// If a file wrapper for the data model objects already exist, delete it first.
    // (To replace a file wrapper you must first delete the existing one; adding
    //  a file wrapper with the same name will NOT replace an existing wrapper.)
	NSFileWrapper *thingsWrapper = docWrapper.fileWrappers[kThingsPreferredName];
	if (thingsWrapper!=nil)
		[docWrapper removeFileWrapper:thingsWrapper];

	// Archive (serialize) the things array and add it to the package.
	NSData *thingsData = [NSKeyedArchiver archivedDataWithRootObject:things];
	// Add the serialized data as a regular files wrapper. Since the code just
	//	checked for (and deleted) any file wrapper with that name, the
	//	key for this file wrapper will be the same as its preferred name.
	[docWrapper addRegularFileWithContents:thingsData
						 preferredFilename:kThingsPreferredName];
	
	// Return the root file wrapper, which UIDocument will use to store the document.
	return docWrapper;
}

- (BOOL)loadFromContents:(id)contents ofType:(NSString *)typeName error:(NSError *__autoreleasing *)outError
{
	// Sent by UIDocument when it wants to load the data in a document.
	// |contents| contains the package's directory wrapper.
	
	// Convert the data in |contents| (which will be in the same form as the
	//	value you returned in -contentsForType:error:). In this app, |contents|
	//	is an NSFileWrapper containing a bunch of subfiles. One of those is
	//	an archived version of the |things| array, which is unarchived
	//	immediately. The rest of the files are PNG image files that the
	//	MyWhatsit objects will read, as needed, in their own time.
	docWrapper = contents;
	
	// Immediatley unarchive the whatsit objects from the data in the file wrapper.
	//	This is very fast, because (without the images) these objects are very lightweight.
	NSFileWrapper *thingsWrapper = docWrapper.fileWrappers[kThingsPreferredName];
	NSData *thingsData = thingsWrapper.regularFileContents;
	if (thingsData!=nil)
        {
		things = [NSKeyedUnarchiver unarchiveObjectWithData:thingsData];
        // Connect every one of the MyWhatsit objects in the unarchived array
        //	to this document object. This is how the individual whatsit objects
        //	will load/save their own images.
        [things makeObjectsPerformSelector:@selector(setDocument:) withObject:self];
        }
	
	return (things!=nil);
}

#pragma mark MyWhatit Objects

- (NSUInteger)whatsitCount
{
	return things.count;
}

- (MyWhatsit*)whatsitAtIndex:(NSUInteger)index
{
	return things[index];
}

- (NSUInteger)indexOfWhatsit:(MyWhatsit*)object
{
	return [things indexOfObject:object];
}

- (void)removeWhatsitAtIndex:(NSUInteger)index
{
	// Remove a MyWhatis object from the collection.
	MyWhatsit *thing = things[index];
	if (thing.imageKey!=nil)
		// The object has storing its image data in the document; remove it
		[self setImage:nil existingKey:thing.imageKey];
	[things removeObjectAtIndex:index];
	[self updateChangeCount:UIDocumentChangeDone];
}

- (MyWhatsit*)anotherWhatsit
{
	// Create a new object and connect it to the document
	// Create a new MyWhatsit object using the generated name and an empty location property
	MyWhatsit *newItem = [MyWhatsit new];
	newItem.name = [NSString stringWithFormat:@"My Item %u",self.whatsitCount+1];
	// Connect the object to this document, which is where it will load/save its image data.
	newItem.document = self;
	// Insert the new object to the end of the collection
	[things addObject:newItem];
	
	[self updateChangeCount:UIDocumentChangeDone];
	return newItem;
}

- (void)whatsitDidChange:(NSNotification *)notification
{
    if ([self indexOfWhatsit:notification.object]!=NSNotFound)
        [self updateChangeCount:UIDocumentChangeDone];
}

#pragma mark Image Storage

- (NSString*)setImage:(UIImage *)image existingKey:(NSString *)key
{
	// If |key| is not nil, it indicates the key that a previous
	//	image was stored under. The previous image file is first
	//	deleted, before creating a new image file from the image.
	// Returns the key the new image was stored under.
	
	if (key!=nil)
		{
		// An image file for the key might already be in the document package.
		// Delete it before creating a new file wrapper.
		NSFileWrapper *imageWrapper = docWrapper.fileWrappers[key];
		if (imageWrapper!=nil)
			[docWrapper removeFileWrapper:imageWrapper];
		}
    
	NSString *newKey = nil;
	if (image!=nil)
		{
		// Convert the image into PNG file data
		NSData *imageData = UIImagePNGRepresentation(image);
		// Add the file data to the document package
		newKey = [docWrapper addRegularFileWithContents:imageData
									  preferredFilename:kImagePreferredName];
		}
	
	[self updateChangeCount:UIDocumentChangeDone];
	return newKey;
}

- (UIImage*)imageForKey:(NSString *)key
{
	// Find the file wrapper for the given key, read its data, and turn
	//	that data back into a UIImage object.
	UIImage *image = nil;
	if (key!=nil)
		{
		NSFileWrapper *imageWrapper = docWrapper.fileWrappers[key];
		if (imageWrapper!=nil)
			image = [UIImage imageWithData:imageWrapper.regularFileContents];
		}
	return image;
}

@end
