//
//  ViewController.m
//  AttributedLabel
//
//  Created by James Bucanek on 9/20/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	NSMutableAttributedString *fancyString;
	fancyString = [[NSMutableAttributedString alloc] initWithString:@"iOS "];
	NSDictionary *iOSAttrs = @{
                               NSFontAttributeName: [UIFont italicSystemFontOfSize:30],
                               NSForegroundColorAttributeName: [UIColor redColor],
                               NSKernAttributeName: @4, };
	[fancyString setAttributes:iOSAttrs range:NSMakeRange(0,3)];
	
	NSDictionary *appAttrs = @{
                               NSFontAttributeName: [UIFont boldSystemFontOfSize:28],
                               NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle) };
	NSAttributedString *secondString;
	secondString = [[NSAttributedString alloc] initWithString:@"App!"
												   attributes:appAttrs];
	[fancyString appendAttributedString:secondString];
	
	self.label.attributedText = fancyString;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
