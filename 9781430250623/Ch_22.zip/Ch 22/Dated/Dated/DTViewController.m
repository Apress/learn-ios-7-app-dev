//
//  DTViewController.m
//  Dated
//
//  Created by James Bucanek on 11/11/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "DTViewController.h"

@interface DTViewController ()
@property (weak,nonatomic) IBOutlet UITextView *dateView;
@property (weak,nonatomic) IBOutlet UIDatePicker *datePicker;
- (IBAction)pickDate:(id)sender;
@end

@implementation DTViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Get the current date, convert it to an integer, and strip off the seconds
    unsigned long long int seconds = [[NSDate date] timeIntervalSinceReferenceDate];
    seconds -= seconds%60;
    // Convert the number of seconds since the reference date into a date object
    NSDate *date = [NSDate dateWithTimeIntervalSinceReferenceDate:seconds];
    // Set the date picker to "right now"
    self.datePicker.date = date;
    // Tell the date picker to fire its "value changed" action.
    // This will send the -pickDate: action, updating the text view.
    [self.datePicker sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pickDate:(id)sender
{
    // Use the NSDateFormatter convienence class method to
    //  convert the date object into a readable string,
    //  localized for the user's current language and
    //  date/time preferences.
    self.dateView.text = [NSDateFormatter localizedStringFromDate:self.datePicker.date
                                                        dateStyle:NSDateFormatterFullStyle
                                                        timeStyle:NSDateFormatterLongStyle];
}

@end
