//
//  MKPointAnnotation+HPPreservation.h
//  Pigeon
//
//  Created by James Bucanek on 11/8/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MKPointAnnotation (HPPreservation)

- (NSDictionary*)preserveState;
- (void)restoreState:(NSDictionary*)state;

@end
