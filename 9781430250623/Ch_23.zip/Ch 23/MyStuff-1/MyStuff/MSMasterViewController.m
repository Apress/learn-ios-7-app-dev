//
//  MSMasterViewController.m
//  MyStuff
//
//  Created by James Bucanek on 9/24/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "MSMasterViewController.h"

#import "MSDetailViewController.h"
#import "MSThingsDocument.h"
#import "MyWhatsit.h"


@interface MSMasterViewController ()
{
    MSThingsDocument *document;
}
- (void)whatsitDidChangeNotification:(NSNotification*)notification;
@end

@implementation MSMasterViewController

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)awakeFromNib
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        self.clearsSelectionOnViewWillAppear = NO;
        self.preferredContentSize = CGSizeMake(320.0, 600.0);
    }
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(whatsitDidChangeNotification:)
                                                 name:kWhatsitDidChangeNotification
                                               object:nil];
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
    self.detailViewController = (MSDetailViewController *)[[self.splitViewController.viewControllers lastObject] topViewController];
	
	// Open/create the "Things" document and make it the data model
	document = [MSThingsDocument documentAtURL:[MSThingsDocument documentURL]];
	// Make this object the document's delegate
	document.delegate = self;
	// The initial document loading process runs in the background. When it's
	//	finished, it will send its delegate (this view controller) a message.
	//	This will signal the view controller to reload the table. Until then,
	//	the document has an empty model and the initial table view will
	//	display nothing until the document finishes loading.
	// Note: In a really robust design, you'd want to prevent the user from
	//	editing the table until the document finished loading. This isn't
	//	a problem for MyStuff because its document is so small and quick to
	//	load. But for larger documents (like word processing, spreadsheets,
	//	or slideshow docs), you'd either present a "loading" screen while the
	//	document was loading, or you'd disable all editing in the view
	//	until the document data became available.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender
{
	// Create a new object
	MyWhatsit *newItem = [document anotherWhatsit];

	// Notify the table view that a new object was just inserted into the data model, and where
    NSUInteger newIndex = [document indexOfWhatsit:newItem];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:newIndex inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return document.whatsitCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

	MyWhatsit *thing = [document whatsitAtIndex:indexPath.row];
	cell.textLabel.text = thing.name;
	cell.detailTextLabel.text = thing.location;
	cell.imageView.image = thing.viewImage;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [document removeWhatsitAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        MyWhatsit *object = [document whatsitAtIndex:indexPath.row];
        self.detailViewController.detailItem = object;
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        MyWhatsit *object = [document whatsitAtIndex:indexPath.row];
        [[segue destinationViewController] setDetailItem:object];
    }
}

#pragma mark Data model

- (void)whatsitDidChangeNotification:(NSNotification*)notification
{
	// Received whenever a MyWhatsit object is edited.
	// Find the object in this table (if it is in this table)
	NSUInteger index = [document indexOfWhatsit:notification.object];
	if (index!=NSNotFound)
        {
		// The MyWhatsit object that changed in our table; tell the table view it has been updated
		NSIndexPath *path = [NSIndexPath indexPathForItem:index inSection:0];
		[self.tableView reloadRowsAtIndexPaths:@[path]
							  withRowAnimation:UITableViewRowAnimationNone];
        }
}

- (void)gotThings:(MSThingsDocument *)document
{
	// The document finished loading.
	// Reload the table. This will cause the table view to reexamine the contents
	//	of its data source/model and redisplay all of the rows.
	// In an iCloud design, you could reuse this (or a similar) method to notify the
	//	view controller that a modified version of the document has appeared in
	//	the cloud, and the document has updated itself with the new information.
	[self.tableView reloadData];
}

@end
