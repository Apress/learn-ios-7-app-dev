//
//  MyWhatsit.h
//  MyStuff
//
//  Created by James Bucanek on 9/25/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MSThingsDocument;

#define kWhatsitDidChangeNotification		@"MyWhatsitDidChange"


@interface MyWhatsit : NSObject <NSCoding,NSCopying>

@property (strong,nonatomic) NSString* name;
@property (strong,nonatomic) NSString* location;
@property (strong,nonatomic) UIImage *image;
@property (readonly,nonatomic) UIImage *viewImage;

@property (weak,nonatomic) MSThingsDocument *document;
@property (readonly,nonatomic) NSString *imageKey;

- (void)postDidChangeNotification;
- (void)memoryWarning;

@end
