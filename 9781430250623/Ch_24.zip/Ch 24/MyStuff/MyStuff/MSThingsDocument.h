//
//  MSThingsDocument.h
//  MyStuff
//
//  Created by James Bucanek on 11/9/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyWhatsit;
@protocol MSThingsDocumentDelegate;

@interface MSThingsDocument : UIDocument

+ (NSURL*)documentURL;
+ (MSThingsDocument*)documentAtURL:(NSURL*)url;

@property (weak) id<MSThingsDocumentDelegate> delegate;

@property (readonly) NSUInteger whatsitCount;
- (MyWhatsit*)whatsitAtIndex:(NSUInteger)index;
- (NSUInteger)indexOfWhatsit:(MyWhatsit*)object;
- (void)removeWhatsitAtIndex:(NSUInteger)index;
- (MyWhatsit*)anotherWhatsit;

- (NSString*)setImage:(UIImage*)image existingKey:(NSString*)key;
- (UIImage*)imageForKey:(NSString*)key;
@property (readonly) NSOperationQueue *editOperations;

@end


// Delegate protocol
@protocol MSThingsDocumentDelegate <NSObject>
@optional
- (void)gotThings:(MSThingsDocument*)document;
@end
