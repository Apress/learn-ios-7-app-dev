//
//  MyWhatsit.m
//  MyStuff
//
//  Created by James Bucanek on 9/25/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "MyWhatsit.h"

#import "MSThingsDocument.h"

#define kNameCoderKey		@"name"
#define kLocationCoderKey	@"location"
#define kImageKeyCoderKey	@"image.key"


@interface MyWhatsit () // private
{
	UIImage *image;
	NSString *imageKey;
}
@end


@implementation MyWhatsit

- (id)initWithCoder:(NSCoder *)decoder
{
	self = [super init];
	if (self!=nil)
		{
		_name =		[decoder decodeObjectForKey:kNameCoderKey];
		_location =	[decoder decodeObjectForKey:kLocationCoderKey];
		imageKey =	[decoder decodeObjectForKey:kImageKeyCoderKey];
		}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
	[coder encodeObject:_name		forKey:kNameCoderKey];
	[coder encodeObject:_location	forKey:kLocationCoderKey];
	[coder encodeObject:imageKey	forKey:kImageKeyCoderKey];
}

- (id)copyWithZone:(NSZone *)zone
{
	MyWhatsit *copy = [[[self class] alloc] init];
	if (copy!=nil)
		{
		copy->_name = _name;
		copy->_location = _location;
		copy->image = image;
		copy->imageKey = imageKey;
		}
	return copy;
}

- (void)postDidChangeNotification
{
    NSNotification *notification = [NSNotification notificationWithName:kWhatsitDidChangeNotification
                                                                 object:self];
    [[NSNotificationQueue defaultQueue] enqueueNotification:notification
                                               postingStyle:NSPostWhenIdle];
}

#pragma mark Image

- (UIImage*)image
{
    @synchronized (self)
    {
	if (image==nil && imageKey!=nil)
		{
		// There is no image object, but there is a key into the document package.
		// This means that this whatsit object has not read its image from
		//	the document package yet.
		image = [_document imageForKey:imageKey];
		}
    }
	return image;
}

- (void)setImage:(UIImage *)newImage
{
	// Store the image, as a file, in the document package
    [_document.editOperations addOperationWithBlock:^{
        self.imageKey = [_document setImage:newImage existingKey:imageKey];
        }];
	image = newImage;
}

- (NSString*)imageKey
{
	return imageKey;
}

- (void)setImageKey:(NSString *)key
{
    @synchronized (self)
    {
    imageKey = key;
    }
}

- (UIImage*)viewImage
{
	// In a well organized application, this method would be in a category of MyWhatsit;
	//	it's fundamentally view logic, not data model logic, and it's tied
	//	to a view logic resource (the camera.png file).
	if (self.image)
		return self.image;
	return [UIImage imageNamed:@"camera"];
}

#pragma mark System Events

- (void)memoryWarning
{
	// Memory is running low
	// MyWhatsit objects that have a UIImage that can be
	//	recreated from from the document can release it.
	//	The next request for the image will load it again.
	if (imageKey!=nil && image!=nil)
		image = nil;
}

@end
