//
//  main.m
//  Shorty
//
//  Created by James Bucanek on 9/22/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SUAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SUAppDelegate class]));
    }
}
