//
//  EBViewController.m
//  EightBall
//
//  Created by James Bucanek on 9/23/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "EBViewController.h"

// Static array of answers
static NSString* gAnswers[] = {
	@"\rYES",
	@"\rNO",
	@"\rMAYBE",
	@"I\rDON'T\rKNOW",
	@"TRY\rAGAIN\rSOON",
	@"READ\rTHE\rMANUAL"
};
// A constant that evaluates to the number of elements in the gAnswers array
#define kNumberOfAnswers (sizeof(gAnswers)/sizeof(NSString*))


@interface EBViewController () // private methods
- (void)orientationChanged:(NSNotification *)notification;
- (void)fadeFortune;
- (void)newFortune;
@end


@implementation EBViewController

- (void)viewDidAppear:(BOOL)animated
{
	[UIDevice.currentDevice beginGeneratingDeviceOrientationNotifications];
	[NSNotificationCenter.defaultCenter addObserver:self
										   selector:@selector(orientationChanged:)
											   name:UIDeviceOrientationDidChangeNotification
											 object:nil];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[NSNotificationCenter.defaultCenter removeObserver:self];
	[UIDevice.currentDevice endGeneratingDeviceOrientationNotifications];
}

#pragma mark Orientation change notification

- (void)orientationChanged:(NSNotification *)notification
{
	if ( UIDevice.currentDevice.orientation==UIDeviceOrientationFaceUp )
		// Device is face up: show message
		[self newFortune];
	else
		// Device is in any other orientation: hide message
		[self fadeFortune];
}

#pragma mark Wisdom

- (void)fadeFortune
{
	[UIView animateWithDuration:0.75 animations:^{
		self.answerView.alpha = 0.0;
    }];
}

- (void)newFortune
{
	// Choose a different answer at random
	self.answerView.text = gAnswers[arc4random_uniform(kNumberOfAnswers)];
	
	// Animate the view so the answer slowly appears
	[UIView animateWithDuration:2.0 animations:^{
		self.answerView.alpha = 1.0;
    }];
}

@end
