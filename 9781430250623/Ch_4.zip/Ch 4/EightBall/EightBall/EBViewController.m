//
//  EBViewController.m
//  EightBall
//
//  Created by James Bucanek on 9/23/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "EBViewController.h"

// Static array of answers
static NSString* gAnswers[] = {
	@"\rYES",
	@"\rNO",
	@"\rMAYBE",
	@"I\nDON'T\nKNOW",
	@"TRY\rAGAIN\rSOON",
	@"READ\rTHE\rMANUAL"
};
// A constant that evaluates to the number of elements in the gAnswers array
#define kNumberOfAnswers (sizeof(gAnswers)/sizeof(NSString*))


@interface EBViewController () // private methods
- (void)fadeFortune;
- (void)newFortune;
@end


@implementation EBViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Motion events

- (void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
	if (motion==UIEventSubtypeMotionShake)
		// User has started shaking device: make the current fortune disappear
		[self fadeFortune];
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
	if (motion==UIEventSubtypeMotionShake)
		// User has stopped shaking device: make a new fortune appear
		[self newFortune];
}

- (void)motionCancelled:(UIEventSubtype)motion withEvent:(UIEvent *)event
{
	if (motion==UIEventSubtypeMotionShake)
		// User started shaking device, but did not complete gesture: reset
		[self newFortune];
}

#pragma mark Wisdom

- (void)fadeFortune
{
	[UIView animateWithDuration:0.75 animations:^{
		self.answerView.alpha = 0.0;
    }];
}

- (void)newFortune
{
	// Choose a different answer at random
	self.answerView.text = gAnswers[arc4random_uniform(kNumberOfAnswers)];
	
	// Animate the view so the answer slowly appears
	[UIView animateWithDuration:2.0 animations:^{
		self.answerView.alpha = 1.0;
    }];
}

@end
