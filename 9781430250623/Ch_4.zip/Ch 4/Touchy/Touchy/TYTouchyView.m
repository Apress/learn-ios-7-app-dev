//
//  TYTouchyView.m
//  Touchy
//
//  Created by James Bucanek on 9/28/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "TYTouchyView.h"


@interface TYTouchyView () // private
{
	NSArray* touchPoints;
}
- (void)updateTouches:(NSSet*)set;
@end


@implementation TYTouchyView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
	// Fill the view by drawing a black background
	CGContextRef context = UIGraphicsGetCurrentContext();
	[[UIColor blackColor] set];
	CGContextFillRect(context,rect);
	
	// Draw a line/polygon connecting all of the touch points
	UIBezierPath *path = nil;
	if (touchPoints.count>1)
        {
		path = [UIBezierPath bezierPath];
		NSValue* firstLocation = nil;
		for ( NSValue *location in touchPoints )
            {
			if (firstLocation==nil)
                {
				firstLocation = location;
				[path moveToPoint:location.CGPointValue];
                }
			else
                {
				[path addLineToPoint:location.CGPointValue];
                }
            }
		if (touchPoints.count>2)
			// path is more than a single line: close the shape
			[path addLineToPoint:firstLocation.CGPointValue];
		
		[[UIColor lightGrayColor] set];
		path.lineWidth = 6;
		path.lineCapStyle = kCGLineCapRound;
		path.lineJoinStyle = kCGLineJoinRound;
		[path stroke];
        }
	
	unsigned int touchNumber = 1;
    NSDictionary* fontAttrs = @{
        NSFontAttributeName: [UIFont boldSystemFontOfSize:180],
        NSForegroundColorAttributeName: [UIColor yellowColor]
        };
	for ( NSValue *location in touchPoints )
        {
		// Turn the touch number into a string
		NSString *text = [NSString stringWithFormat:@"%u",touchNumber++];
        //		NSLog(@"(drawing %@)",location);
		// Get the graphic dimensions this string would occupy if drawn
		//	with a 32 point bold system font.
        CGSize size = [text sizeWithAttributes:fontAttrs];
		
		// Calculate the top-left corner of the rectangle of |size|
		//	that will center the text over the point the touch occurred
		CGPoint touchPoint = location.CGPointValue;
		CGPoint textCorner = CGPointMake(touchPoint.x-size.width/2,
										 touchPoint.y-size.height/2);
        [text drawAtPoint:textCorner withAttributes:fontAttrs];
        }
}

- (void)updateTouches:(NSSet*)set
{
	// Update the array of coordinates that will be used draw the
	//	touch points in the view.
	// Only include those touches that are still active (began,
	//	moved, or stationary). Other touch objects, like those
	//	representing a location where a touch has been removed),
	//	are excluded.
	// Note that this extracts and saves the important information
	//	about the touch set, but not the set or the touch objects
	//	themselves, because their useful lifespan doesn't extend
	//	beyond this event loop.
	NSMutableArray *array = [NSMutableArray array];
	for ( UITouch *touch in set )
        {
		switch (touch.phase) {
			case UITouchPhaseBegan:
			case UITouchPhaseMoved:
			case UITouchPhaseStationary:
				[array addObject:[NSValue valueWithCGPoint:[touch locationInView:self]]];
				break;
				
			default:
				break;
            }
        }
	touchPoints = array;
	[self setNeedsDisplay];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self updateTouches:event.allTouches];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self updateTouches:event.allTouches];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self updateTouches:event.allTouches];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[self updateTouches:event.allTouches];
}

@end
