//
//  TYViewController.h
//  Touchy
//
//  Created by James Bucanek on 9/28/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYViewController : UIViewController

@end
