//
//  TYViewController.m
//  Touchy
//
//  Created by James Bucanek on 9/28/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "TYViewController.h"

@interface TYViewController ()

@end

@implementation TYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
