//
//  MSDetailViewController.h
//  MyStuff
//
//  Created by James Bucanek on 9/24/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyWhatsit.h"

@interface MSDetailViewController : UIViewController <UISplitViewControllerDelegate>

@property (strong, nonatomic) MyWhatsit *detailItem;

@property (weak,nonatomic) IBOutlet UITextField *nameField;
@property (weak,nonatomic) IBOutlet UITextField *locationField;

- (IBAction)changedDetail:(id)sender;

@end
