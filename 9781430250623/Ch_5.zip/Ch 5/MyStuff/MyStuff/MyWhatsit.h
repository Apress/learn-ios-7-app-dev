//
//  MyWhatsit.h
//  MyStuff
//
//  Created by James Bucanek on 9/25/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kWhatsitDidChangeNotification		@"MyWhatsitDidChange"


@interface MyWhatsit : NSObject

- (id)initWithName:(NSString*)name location:(NSString*)location;

@property (strong,nonatomic) NSString* name;
@property (strong,nonatomic) NSString* location;

- (void)postDidChangeNotification;

@end
