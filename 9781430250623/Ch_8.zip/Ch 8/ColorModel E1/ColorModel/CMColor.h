//
//  CMColor.h
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CMColor : NSObject

@property (nonatomic) float hue;
@property (nonatomic) float saturation;
@property (nonatomic) float brightness;

@property (readonly,nonatomic) UIColor *color;

@end
