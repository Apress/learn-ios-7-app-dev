//
//  CMColor.m
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "CMColor.h"

@implementation CMColor

+ (NSSet*)keyPathsForValuesAffectingColor
{
	return [NSSet setWithObjects:@"hue",@"saturation",@"brightness",nil];
}

- (UIColor*)color
{
	return [UIColor colorWithHue:self.hue/360
					  saturation:self.saturation/100
					  brightness:self.brightness/100
						   alpha:1];
}

@end
