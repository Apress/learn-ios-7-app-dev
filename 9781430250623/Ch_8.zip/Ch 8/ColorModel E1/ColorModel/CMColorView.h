//
//  CMColorView.h
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CMColor.h"

@interface CMColorView : UIView

@property (strong,nonatomic) CMColor *colorModel;

@end
