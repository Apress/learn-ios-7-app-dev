//
//  CMViewController.m
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "CMViewController.h"

@interface CMViewController ()

@end

@implementation CMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	self.colorModel = [CMColor new];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeHue:(UISlider*)sender
{
	self.colorModel.hue = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
}

- (IBAction)changeSaturation:(UISlider*)sender
{
	self.colorModel.saturation = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
}

- (IBAction)changeBrightness:(UISlider*)sender
{
	self.colorModel.brightness = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
}

@end
