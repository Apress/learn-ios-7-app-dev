//
//  CMViewController.m
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "CMViewController.h"

@interface CMViewController ()

@end

@implementation CMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	self.colorModel = [CMColor new];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeHue:(UISlider*)sender
{
	self.colorModel.hue = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
	self.hueLabel.text = [NSString stringWithFormat:@"%.0f\u00b0",
						  self.colorModel.hue];
}

- (IBAction)changeSaturation:(UISlider*)sender
{
	self.colorModel.saturation = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
	self.saturationLabel.text = [NSString stringWithFormat:@"%.0f%%",
								 self.colorModel.saturation];
}

- (IBAction)changeBrightness:(UISlider*)sender
{
	self.colorModel.brightness = sender.value;
	self.colorView.backgroundColor = self.colorModel.color;
	self.brightnessLabel.text = [NSString stringWithFormat:@"%.0f%%",
								 self.colorModel.brightness];
}

@end
