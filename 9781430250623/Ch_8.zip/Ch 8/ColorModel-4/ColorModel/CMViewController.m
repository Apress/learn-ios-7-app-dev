//
//  CMViewController.m
//  ColorModel
//
//  Created by James Bucanek on 10/2/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "CMViewController.h"

@interface CMViewController ()
- (void)updateColor;
@end

@implementation CMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	self.colorModel = [CMColor new];
    self.colorView.colorModel = self.colorModel;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeHue:(UISlider*)sender
{
	self.colorModel.hue = sender.value;
    [self updateColor];
}

- (IBAction)changeSaturation:(UISlider*)sender
{
	self.colorModel.saturation = sender.value;
    [self updateColor];
}

- (IBAction)changeBrightness:(UISlider*)sender
{
	self.colorModel.brightness = sender.value;
    [self updateColor];
}

- (void)updateColor
{
	// Update the color view
	[self.colorView setNeedsDisplay];
    
	// Update the values in the three component text views
	self.hueLabel.text = [NSString stringWithFormat:@"%.0f\u00b0",
						  self.colorModel.hue];
	self.saturationLabel.text = [NSString stringWithFormat:@"%.0f%%",
								 self.colorModel.saturation];
	self.brightnessLabel.text = [NSString stringWithFormat:@"%.0f%%",
								 self.colorModel.brightness];
	
	// Update the web safe value
	CGFloat red, green, blue, alpha;
	[self.colorModel.color getRed:&red green:&green blue:&blue alpha:&alpha];
	self.webLabel.text = [NSString stringWithFormat:@"#%02lx%02lx%02lx",
						  lroundf(red*255),
						  lroundf(green*255),
						  lroundf(blue*255)];
}

@end
