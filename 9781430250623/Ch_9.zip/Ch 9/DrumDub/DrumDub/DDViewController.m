//
//  DDViewController.m
//  DrumDub
//
//  Created by James Bucanek on 10/5/13.
//  Copyright (c) 2013 Apress. All rights reserved.
//

#import "DDViewController.h"

#define kNumberOfPlayers	4		// there are four sound players/buttons
static NSString *SoundName[kNumberOfPlayers] = { @"snare", @"bass", @"tambourine", @"maraca" };

@interface DDViewController ()
{
    MPMusicPlayerController *music; // (store for @property musicPlayer)
	AVAudioPlayer           *players[kNumberOfPlayers];
}
@property (readonly,nonatomic) MPMusicPlayerController *musicPlayer;
- (void)playbackStateDidChangeNotification:(NSNotification*)notification;
- (void)playingItemDidChangeNotification:(NSNotification*)notification;
- (void)createAudioPlayers;
- (void)destroyAudioPlayers;
- (void)activateAudioSession;
- (void)audioRouteChangedNotification:(NSNotification*)notification;
@end

@implementation DDViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[AVAudioSession sharedInstance] setDelegate:self];
    [self activateAudioSession];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(audioRouteChangedNotification:)
                                                 name:AVAudioSessionRouteChangeNotification
                                               object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Music Picker

- (IBAction)selectTrack:(id)sender
{
	// Present the media picker view controller, allowing the user to choose
	//	one track from their iPod library.
	MPMediaPickerController *picker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeAnyAudio];
	picker.delegate = self;
	picker.allowsPickingMultipleItems = NO;
	picker.prompt = @"Choose a song";
    
	// Present the media picker
	[self presentViewController:picker animated:YES completion:nil];
}

- (void)mediaPicker:(MPMediaPickerController*)mediaPicker
  didPickMediaItems:(MPMediaItemCollection*)mediaItemCollection
{
	// Receieved when the user chooses a song from their iPod library
    
	if (mediaItemCollection.count!=0)
		{
		// Set the player's play list to the one song the user picked
		[self.musicPlayer setQueueWithItemCollection:mediaItemCollection];
		// Start the music playing
		[self.musicPlayer play];
		}
	
	// Dismiss the media picker
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)mediaPickerDidCancel:(MPMediaPickerController*)mediaPicker
{
	// Received when the user declines to choose a song from their iPod library
	
	// Dismiss the media picker
	[self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark Music Player

- (MPMusicPlayerController*)musicPlayer
{
    // Lazily created singleton music player object property
    if (music==nil)
        {
        // Create the application's music player object.
        // (If you wanted your application to use/control the device's iPod controller,
        //	use [MPMusicPlayerController iPodMusicPlayer] instead.)
        music = [MPMusicPlayerController applicationMusicPlayer];
        // Manually turn off looping and shuffle modes. By default, a new application
        //	music player will have the same settings as the current iPod player.
        music.shuffleMode = NO;
        music.repeatMode = NO;
        
        // Register to receive music player notifications
        NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
        [notificationCenter addObserver:self
                               selector:@selector(playbackStateDidChangeNotification:)
                                   name:MPMusicPlayerControllerPlaybackStateDidChangeNotification
                                 object:music];
        [notificationCenter addObserver:self
                               selector:@selector(playingItemDidChangeNotification:)
                                   name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification
                                 object:music];
        // You must turn on music player events to receive them
        [music beginGeneratingPlaybackNotifications];
        }
    return music;
}

- (IBAction)play:(id)sender
{
	[self.musicPlayer play];
}

- (IBAction)pause:(id)sender
{
	[self.musicPlayer pause];
}

- (void)playbackStateDidChangeNotification:(NSNotification*)notification
{
	// Received when the player state (playing, paused, seeking, ...) changes
    
    // Determine if the music player is playing or not by looking at its playbackState
    BOOL playing = (music.playbackState==MPMoviePlaybackStatePlaying);
    
    // Enable the play button if the player is NOT playing
    _playButton.enabled = !playing;
    // Enable the pause button if it IS playing
    _pauseButton.enabled = playing;
}

- (void)playingItemDidChangeNotification:(NSNotification*)notification
{
	// Received with the currently playing item changes
	
	// Get the item playing
	MPMediaItem *nowPlaying = music.nowPlayingItem;
	// Note: if nowPlaying is nil (meaning that there's nothing playing), then
	//		 all of its properties will be nil. Setting UILabel to a nil string
	//		 clears the text in the view, which is exactly what should happen
	//		 if nothing is playing.
	
	// Get the album artwork
	MPMediaItemArtwork *artwork = [nowPlaying valueForProperty:MPMediaItemPropertyArtwork];
	UIImage *albumImage = [artwork imageWithSize:_albumView.bounds.size];
	if (albumImage==nil)
		albumImage = [UIImage imageNamed:@"noartwork"];
	_albumView.image = albumImage;
	
	// Set the song title, album title, and artist
	_songLabel.text = [nowPlaying valueForProperty:MPMediaItemPropertyTitle];
	_albumLabel.text = [nowPlaying valueForProperty:MPMediaItemPropertyAlbumTitle];
	_artistLabel.text = [nowPlaying valueForProperty:MPMediaItemPropertyArtist];
}

#pragma mark Audio Players

- (void)createAudioPlayers
{
	// Create the sound players, makes this object their delegate, and
	//	prepare them to play.
	// Creating and preloading the sound player objects now reduces latency
	//	(the delay between tapping the button and playing the sound) later.
	// That's becuase sound players don't read their data and begin decoding
	//	until asked to play. The first time this happens can take a noticable
	//	amount of time, so this code does it up front.
	for ( NSUInteger i=0; i<kNumberOfPlayers; i++)
		{
		NSURL *soundURL = [[NSBundle mainBundle] URLForResource:SoundName[i]
												  withExtension:@"m4a"];
		players[i] = [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL
                                                            error:NULL];
		players[i].delegate = self;
		[players[i] prepareToPlay];
		}
}

- (void)destroyAudioPlayers
{
	for ( NSUInteger i=0; i<kNumberOfPlayers; i++)
		players[i] = nil;
}

- (IBAction)bang:(id)sender
{
	// The tag of the sender (1..4) determines which sound will play ([0]..[3])
	NSInteger playerIndex = [sender tag]-1;
	if (playerIndex>=0 && playerIndex<kNumberOfPlayers)
		{
		AVAudioPlayer *player = players[playerIndex];
		[player pause];				// pause (if it's currently playing)
		player.currentTime = 0;		// rewind to beginning
		[player play];				// start playing
		}
}

- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
	// Received when the audio session is interrupted (by an alarm or incoming phone call).
	// Respond by stopping the sound, so it won't resume playing when the interruption ends.
	[player pause];
}

//- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player withOptions:(NSUInteger)flags
//{
//    // Received when the audio session interruption ends.
//    // This message is not needed in this app.
//}

#pragma mark Audio Session

- (void)activateAudioSession
{
	// While not strictly necessary, the documentation for AVAudioSession
	//	recommends explicitely activating the audio session when your
	//	app starts, and again whenever it's been interrupted or routing
	//	has changed. This gives your app an opportunity to take defensive
	//	action should the audio session be unusable, for some strange reason.
	BOOL active = [[AVAudioSession sharedInstance] setActive:YES error:NULL];
	
    // If the session is active and the AVAudioPlayers need to be created ...
	if (active && players[0]==nil)
		[self createAudioPlayers];          // ... create them
    // If the session failed to active, throw away our audio players on the
    //  theory that they're now useless
	if (!active)
		[self destroyAudioPlayers];
	
	// Enable the four sound buttons when the audio session is active,
    //  and disable them if it isn't.
	for ( NSUInteger i=0; i<kNumberOfPlayers; i++)
		[(UIButton*)[self.view viewWithTag:i+1] setEnabled:active];
}

- (void)endInterruption
{
    [self activateAudioSession];
}

- (void)audioRouteChangedNotification:(NSNotification*)notification
{
	// Determine the reason for the audio route change
	NSNumber *changeReason = notification.userInfo[AVAudioSessionRouteChangeReasonKey];
	if ([changeReason integerValue]==AVAudioSessionRouteChangeReasonOldDeviceUnavailable)
        {
		// The reason was an audio route is no longer available. In English, it
		//	means that someone unplugged their headphones, pulled their iPod out
		//	of a stereo dock, turned off their Bluetooth speakers, etc.
		// Our response is to stop all audio players (consistent with Apple's guidelines)
        for ( NSUInteger i=0; i<kNumberOfPlayers; i++)
            [players[i] pause];
        }
}

@end
